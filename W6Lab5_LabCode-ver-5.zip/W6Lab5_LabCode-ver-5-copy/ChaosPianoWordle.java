import javax.sound.midi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class ChaosPianoWordle extends JPanel {

    // ================= PIANO =================
    private static final int NUM_OCTAVES = 4;
    private static final int WHITE_PER_OCT = 7;
    private static final int BLACK_PER_OCT = 5;

    private Rectangle[] whiteKeys;
    private Rectangle[] blackKeys;
    private int[] whiteNotes;
    private int[] blackNotes;

    private Synthesizer synth;
    private MidiChannel channel;

    private Random rand = new Random();

    // ================= WORDLE =================
    private String[] words = {
            "APPLE","GRAPE","PLANT","TRAIN","BRICK",
            "STONE","CHAIR","TABLE","SHEEP","CRANE",
            "LIGHT","PLANE","WORLD","MOUSE","SOUND",
            "ROBOT","CLOUD","HEART","WATER","SUGAR"
    };

    private String targetWord;
    private String[] guesses = new String[6];
    private int row = 0;
    private String current = "";

    private Color[][] colors = new Color[6][5];

    // ================= LETTER SYSTEM =================
    private char[] letters;
    private int[] map;

    private boolean curseActive = false;
    private char cursedChar;

    // ================= CHAOS KEYS =================
    private int crashKey;
    private int popupKey;
    private int curseKey;
    private int jumbleKey;

    private boolean crashUsed = false;
    private boolean popupUsed = false;
    private boolean curseUsed = false;
    private boolean jumbleUsed = false;

    public ChaosPianoWordle() {

        setPreferredSize(new Dimension(900, 520));

        initMidi();
        buildPiano();
        initLetters();

        pickWord();
        assignChaos();

        addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {

                int key = getKey(e.getPoint());
                if (key == -1) return;

                play(getNote(key));

                handleChaos(key);
                handleInput(key);

                repaint();
            }

            public void mouseReleased(MouseEvent e) {
                int key = getKey(e.getPoint());
                if (key != -1) stop(getNote(key));
            }
        });
    }

    // ================= MIDI =================

    private void initMidi() {
        try {
            synth = MidiSystem.getSynthesizer();
            synth.open();
            channel = synth.getChannels()[0];
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void play(int n) {
        if (channel != null) channel.noteOn(n, 90);
    }

    private void stop(int n) {
        if (channel != null) channel.noteOff(n);
    }

    // ================= PIANO =================

    private void buildPiano() {

        int wCount = NUM_OCTAVES * WHITE_PER_OCT;
        int bCount = NUM_OCTAVES * BLACK_PER_OCT;

        whiteKeys = new Rectangle[wCount];
        blackKeys = new Rectangle[bCount];
        whiteNotes = new int[wCount];
        blackNotes = new int[bCount];

        int x = 10;
        int wi = 0, bi = 0;

        int whiteW = 30, blackW = 18;

        int[] wOff = {0,2,4,5,7,9,11};
        int[] bOff = {1,3,6,8,10};

        int pianoY = 320;

        for (int o = 0; o < NUM_OCTAVES; o++) {

            for (int i = 0; i < 7; i++) {
                whiteKeys[wi] = new Rectangle(x, pianoY, whiteW, 180);
                whiteNotes[wi] = 60 + o * 12 + wOff[i];
                wi++;
                x += whiteW;
            }

            int base = 10 + o * 7 * whiteW;

            int[] bx = {
                    whiteW - 9,
                    2 * whiteW - 9,
                    4 * whiteW - 9,
                    5 * whiteW - 9,
                    6 * whiteW - 9
            };

            for (int i = 0; i < 5; i++) {
                blackKeys[bi] = new Rectangle(base + bx[i], pianoY, blackW, 110);
                blackNotes[bi] = 60 + o * 12 + bOff[i];
                bi++;
            }
        }
    }

    private int getKey(Point p) {

        for (int i = 0; i < blackKeys.length; i++)
            if (blackKeys[i].contains(p))
                return whiteKeys.length + i;

        for (int i = 0; i < whiteKeys.length; i++)
            if (whiteKeys[i].contains(p))
                return i;

        return -1;
    }

    private int getNote(int k) {
        if (k < whiteKeys.length) return whiteNotes[k];
        return blackNotes[k - whiteKeys.length];
    }

    // ================= LETTERS =================

    private void initLetters() {

        letters = new char[whiteKeys.length];
        map = new int[26];

        for (int i = 0; i < 26; i++) {
            letters[i] = (char)('A' + i);
            map[i] = i;
        }

        letters[26] = '#'; // ENTER
        letters[27] = '<'; // DELETE
    }

    // ================= WORD =================

    private void pickWord() {
        targetWord = words[rand.nextInt(words.length)];
        System.out.println("WORD: " + targetWord);
    }

    // ================= CHAOS =================

    private void assignChaos() {

        int[] pool = new int[26];

        for (int i = 0; i < 26; i++) pool[i] = i;

        for (int i = 25; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            int t = pool[i];
            pool[i] = pool[j];
            pool[j] = t;
        }

        crashKey = pool[0];
        popupKey = pool[1];
        curseKey = pool[2];
        jumbleKey = pool[3];

        crashUsed = popupUsed = curseUsed = jumbleUsed = false;
    }

    private void handleChaos(int k) {

        if (k == crashKey && !crashUsed) {
            crashUsed = true;
            JOptionPane.showMessageDialog(this, "💀 CRASH");
            System.exit(0);
        }

        if (k == popupKey && !popupUsed) {
            popupUsed = true;
            JOptionPane.showMessageDialog(this, "POPUP!");
        }

        if (k == curseKey && !curseUsed) {
            curseUsed = true;
            curseActive = true;
            cursedChar = (char)('A' + rand.nextInt(26));

            JOptionPane.showMessageDialog(this,
                    "☠ CURSE ACTIVE ☠\nAll letters become: " + cursedChar);
        }

        if (k == jumbleKey && !jumbleUsed) {
            jumbleUsed = true;
            jumbleLetters();
        }
    }

    private void jumbleLetters() {

        for (int i = 25; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            int t = map[i];
            map[i] = map[j];
            map[j] = t;
        }

        JOptionPane.showMessageDialog(this, "🔀 JUMBLE ACTIVE");
    }

    // ================= INPUT =================

    private void handleInput(int k) {

        if (k >= whiteKeys.length) return;

        char c = letters[k < 26 ? map[k] : k];

        if (curseActive && k < 26)
            c = cursedChar;

        if (c == '<') {
            if (current.length() > 0)
                current = current.substring(0, current.length() - 1);
            return;
        }

        if (c == '#') {
            if (current.length() == 5) {
                guesses[row] = current;
                evaluate(current, row);
                row++;
                current = "";
                curseActive = false;
                assignChaos();
            }
            return;
        }

        if (current.length() < 5 && Character.isLetter(c))
            current += c;
    }

    private void evaluate(String g, int r) {

        for (int i = 0; i < 5; i++) {

            char a = g.charAt(i);
            char b = targetWord.charAt(i);

            if (a == b) colors[r][i] = Color.GREEN;
            else if (targetWord.indexOf(a) != -1) colors[r][i] = Color.YELLOW;
            else colors[r][i] = Color.GRAY;
        }
    }

    // ================= DRAW =================

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // ===== WORDLE =====
        int sx = 120, sy = 20, s = 40;

        for (int r = 0; r < 6; r++) {
            for (int c = 0; c < 5; c++) {

                int x = sx + c * (s + 5);
                int y = sy + r * (s + 5);

                g.setColor(colors[r][c] != null ? colors[r][c] : Color.LIGHT_GRAY);
                g.fillRect(x, y, s, s);

                g.setColor(Color.BLACK);
                g.drawRect(x, y, s, s);

                String t = (r < row && guesses[r] != null) ?
                        "" + guesses[r].charAt(c) :
                        (r == row && c < current.length()) ?
                        "" + current.charAt(c) : "";

                g.drawString(t, x + 15, y + 25);
            }
        }

        // ===== PIANO =====
        for (int i = 0; i < whiteKeys.length; i++) {

            Rectangle r = whiteKeys[i];

            if (i == crashKey) g.setColor(Color.RED);
            else if (i == popupKey) g.setColor(Color.YELLOW);
            else if (i == curseKey) g.setColor(Color.MAGENTA);
            else if (i == jumbleKey) g.setColor(Color.CYAN);
            else g.setColor(Color.WHITE);

            g.fillRect(r.x, r.y, r.width, r.height);
            g.setColor(Color.BLACK);
            g.drawRect(r.x, r.y, r.width, r.height);

            // 🔥 RESTORED LETTERS
            String label = (i == 26) ? "ENTER"
                         : (i == 27) ? "DEL"
                         : "" + letters[i];

            g.drawString(label, r.x + 8, r.y + 150);
        }

        for (Rectangle r : blackKeys) {
            g.setColor(Color.BLACK);
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    // ================= MAIN =================

    public static void main(String[] args) {
        JFrame f = new JFrame("Chaos Piano Wordle");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(new ChaosPianoWordle());
        f.pack();
        f.setVisible(true);
    }
}