import javax.sound.midi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Q3SolutionFourOctavePiano extends JPanel {

    private static final int NUM_OCTAVES = 4;
    private static final int WHITE_PER_OCT = 7;
    private static final int BLACK_PER_OCT = 5;

    private static final int MAX_SHIFT = 23 * 12;
    private int octaveShift = 0;

    private Rectangle[] whiteKeys;
    private Rectangle[] blackKeys;
    private int[] whiteKeyNotes;
    private int[] blackKeyNotes;

    private Synthesizer synth;
    private MidiChannel channel;

    // Popup trap key
    private int trapKeyIndex = -1;
    private boolean trapIsWhite = true;

    // Crash key
    private int crashKeyIndex = -1;
    private boolean crashIsWhite = true;

    // Timed curse key
    private int timedKeyIndex = -1;
    private boolean timedIsWhite = true;
    private boolean timedCurseActive = false;
    private int timedCurseNote = -1;

    // NEW: Random octave key
    private int randomOctaveKeyIndex = -1;
    private boolean randomOctaveIsWhite = true;

    private final Random rand = new Random();
    private JFrame parentFrame;

    public Q3SolutionFourOctavePiano() {
        setPreferredSize(new Dimension(900, 240));
        initMidi();
        buildKeys();

        chooseRandomTrapKey();
        chooseRandomCrashKey();
        chooseRandomTimedKey();
        chooseRandomOctaveKey(); // NEW

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Point p = e.getPoint();

                // CRASH KEY
                if (isCrashKeyPressed(p)) {
                    triggerCrash(parentFrame);
                    return;
                }

                // RANDOM OCTAVE KEY
                if (isRandomOctaveKeyPressed(p)) {
                    triggerRandomOctave();
                    return;
                }

                // TIMED CURSE KEY
                if (isTimedKeyPressed(p)) {
                    triggerTimedCurse();
                    return;
                }

                // POPUP TRAP KEY
                if (isTrapKeyPressed(p)) {
                    triggerPopups();
                    chooseRandomTrapKey();
                    chooseRandomCrashKey();
                    chooseRandomTimedKey();
                    chooseRandomOctaveKey(); // keep refreshing
                    repaint();
                }

                int note = getNoteAtPoint(p);

                if (note != -1) {
                    if (timedCurseActive) {
                        playNote(timedCurseNote);
                    } else {
                        playNote(note);
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                int note = getNoteAtPoint(e.getPoint());
                if (note != -1) stopNote(note);
            }
        });
    }

    public void setParentFrame(JFrame frame) {
        this.parentFrame = frame;
    }

    private void initMidi() {
        try {
            synth = MidiSystem.getSynthesizer();
            synth.open();
            channel = synth.getChannels()[0];
            channel.programChange(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buildKeys() {
        int numWhite = NUM_OCTAVES * WHITE_PER_OCT;
        int numBlack = NUM_OCTAVES * BLACK_PER_OCT;

        whiteKeys = new Rectangle[numWhite];
        blackKeys = new Rectangle[numBlack];
        whiteKeyNotes = new int[numWhite];
        blackKeyNotes = new int[numBlack];

        int whiteW = 30, whiteH = 180;
        int blackW = 18, blackH = 110;

        int x = 10;
        int wi = 0, bi = 0;

        int[] whiteOffsets = {0, 2, 4, 5, 7, 9, 11};
        int[] blackOffsets = {1, 3, 6, 8, 10};

        for (int oct = 0; oct < NUM_OCTAVES; oct++) {

            for (int i = 0; i < whiteOffsets.length; i++) {
                whiteKeys[wi] = new Rectangle(x, 50, whiteW, whiteH);
                whiteKeyNotes[wi] = 60 + oct * 12 + whiteOffsets[i];
                wi++;
                x += whiteW;
            }

            int baseX = 10 + oct * WHITE_PER_OCT * whiteW;
            int[] blackXOffsets = {
                    whiteW - blackW / 2,
                    2 * whiteW - blackW / 2,
                    4 * whiteW - blackW / 2,
                    5 * whiteW - blackW / 2,
                    6 * whiteW - blackW / 2
            };

            for (int i = 0; i < blackOffsets.length; i++) {
                blackKeys[bi] = new Rectangle(
                        baseX + blackXOffsets[i],
                        50,
                        blackW,
                        blackH
                );
                blackKeyNotes[bi] = 60 + oct * 12 + blackOffsets[i];
                bi++;
            }
        }
    }

    private int getNoteAtPoint(Point p) {
        for (int i = 0; i < blackKeys.length; i++)
            if (blackKeys[i].contains(p))
                return blackKeyNotes[i] + octaveShift;

        for (int i = 0; i < whiteKeys.length; i++)
            if (whiteKeys[i].contains(p))
                return whiteKeyNotes[i] + octaveShift;

        return -1;
    }

    private void playNote(int note) {
        if (channel != null && note >= 0 && note <= 127)
            channel.noteOn(note, 90);
    }

    private void stopNote(int note) {
        if (channel != null && note >= 0 && note <= 127)
            channel.noteOff(note);
    }

    // Trap key
    private void chooseRandomTrapKey() {
        trapIsWhite = rand.nextBoolean();
        trapKeyIndex = trapIsWhite ?
                rand.nextInt(whiteKeys.length) :
                rand.nextInt(blackKeys.length);
    }

    private boolean isTrapKeyPressed(Point p) {
        return trapIsWhite ?
                whiteKeys[trapKeyIndex].contains(p) :
                blackKeys[trapKeyIndex].contains(p);
    }

    private void triggerPopups() {
        for (int i = 0; i < 5; i++) {
            JOptionPane.showMessageDialog(this,
                    "You pressed the cursed popup key!",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    // Crash key
    private void chooseRandomCrashKey() {
        crashIsWhite = rand.nextBoolean();
        do {
            crashKeyIndex = crashIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while ((crashIsWhite == trapIsWhite && crashKeyIndex == trapKeyIndex));
    }

    private boolean isCrashKeyPressed(Point p) {
        return crashIsWhite ?
                whiteKeys[crashKeyIndex].contains(p) :
                blackKeys[crashKeyIndex].contains(p);
    }

    private void triggerCrash(JFrame frame) {
        JOptionPane.showMessageDialog(this,
                "CRASH KEY pressed!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        if (frame != null) frame.dispose();
    }

    // Timed key
    private void chooseRandomTimedKey() {
        timedIsWhite = rand.nextBoolean();
        do {
            timedKeyIndex = timedIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while (
                (timedIsWhite == trapIsWhite && timedKeyIndex == trapKeyIndex) ||
                (timedIsWhite == crashIsWhite && timedKeyIndex == crashKeyIndex)
        );
    }

    private boolean isTimedKeyPressed(Point p) {
        return timedIsWhite ?
                whiteKeys[timedKeyIndex].contains(p) :
                blackKeys[timedKeyIndex].contains(p);
    }

    private void triggerTimedCurse() {
        timedCurseActive = true;

        timedCurseNote = timedIsWhite ?
                whiteKeyNotes[timedKeyIndex] :
                blackKeyNotes[timedKeyIndex];

        Timer timer = new Timer(20000, e -> {
            timedCurseActive = false;
            chooseRandomTimedKey();
            repaint();
        });

        timer.setRepeats(false);
        timer.start();
    }

    // NEW RANDOM OCTAVE KEY
    private void chooseRandomOctaveKey() {
        randomOctaveIsWhite = rand.nextBoolean();

        do {
            randomOctaveKeyIndex = randomOctaveIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while (
                (randomOctaveIsWhite == trapIsWhite && randomOctaveKeyIndex == trapKeyIndex) ||
                (randomOctaveIsWhite == crashIsWhite && randomOctaveKeyIndex == crashKeyIndex) ||
                (randomOctaveIsWhite == timedIsWhite && randomOctaveKeyIndex == timedKeyIndex)
        );
    }

    private boolean isRandomOctaveKeyPressed(Point p) {
        return randomOctaveIsWhite ?
                whiteKeys[randomOctaveKeyIndex].contains(p) :
                blackKeys[randomOctaveKeyIndex].contains(p);
    }

    private void triggerRandomOctave() {
        int randomOctave = rand.nextInt(5) - 2; // -2 to +2
        octaveShift = randomOctave * 12;

        JOptionPane.showMessageDialog(this,
                "Random Octave: " + randomOctave);

        chooseRandomOctaveKey();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int i = 0; i < whiteKeys.length; i++) {
            if (trapIsWhite && i == trapKeyIndex)
                g.setColor(Color.YELLOW);
            else if (crashIsWhite && i == crashKeyIndex)
                g.setColor(Color.MAGENTA);
            else if (timedIsWhite && i == timedKeyIndex)
                g.setColor(Color.GREEN);
            else if (randomOctaveIsWhite && i == randomOctaveKeyIndex)
                g.setColor(Color.CYAN);
            else
                g.setColor(Color.WHITE);

            Rectangle r = whiteKeys[i];
            g.fillRect(r.x, r.y, r.width, r.height);
            g.setColor(Color.BLACK);
            g.drawRect(r.x, r.y, r.width, r.height);
        }

        for (int i = 0; i < blackKeys.length; i++) {
            if (!trapIsWhite && i == trapKeyIndex)
                g.setColor(Color.RED);
            else if (!crashIsWhite && i == crashKeyIndex)
                g.setColor(Color.MAGENTA);
            else if (!timedIsWhite && i == timedKeyIndex)
                g.setColor(Color.GREEN);
            else if (!randomOctaveIsWhite && i == randomOctaveKeyIndex)
                g.setColor(Color.CYAN);
            else
                g.setColor(Color.BLACK);

            Rectangle r = blackKeys[i];
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    public void shiftOctave(int semitones) {
        int newShift = octaveShift + semitones;
        if (Math.abs(newShift) <= MAX_SHIFT) {
            octaveShift = newShift;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            Q3SolutionFourOctavePiano piano = new Q3SolutionFourOctavePiano();

            JButton down = new JButton("Octave -");
            JButton up = new JButton("Octave +");

            down.addActionListener(e -> piano.shiftOctave(-12));
            up.addActionListener(e -> piano.shiftOctave(+12));

            JPanel controls = new JPanel();
            controls.add(down);
            controls.add(up);

            JFrame frame = new JFrame("4-Octave Piano");
            piano.setParentFrame(frame);

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            frame.add(controls, BorderLayout.NORTH);
            frame.add(piano, BorderLayout.CENTER);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}