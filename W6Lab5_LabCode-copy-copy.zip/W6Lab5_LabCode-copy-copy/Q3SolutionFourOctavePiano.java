import javax.sound.midi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Q3SolutionFourOctavePiano extends JPanel {

    private static final int NUM_OCTAVES = 4;
    private static final int WHITE_PER_OCT = 7;
    private static final int BLACK_PER_OCT = 5;

    private static final int MAX_SHIFT = 23 * 12;
    private int octaveShift = 0;

    private Rectangle[] whiteKeys;
    private Rectangle[] blackKeys;
    private int[] whiteKeyNotes;
    private int[] blackKeyNotes;

    private Synthesizer synth;
    private MidiChannel channel;

    // Special keys
    private int trapKeyIndex = -1;
    private boolean trapIsWhite = true;

    private int crashKeyIndex = -1;
    private boolean crashIsWhite = true;

    private int timedKeyIndex = -1;
    private boolean timedIsWhite = true;
    private boolean timedCurseActive = false;
    private int timedCurseNote = -1;

    private int randomOctaveKeyIndex = -1;
    private boolean randomOctaveIsWhite = true;

    // Jumble key
    private int jumbleKeyIndex = -1;
    private boolean jumbleIsWhite = true;
    private boolean jumbleActive = false;

    private final Random rand = new Random();
    private JFrame parentFrame;

    public Q3SolutionFourOctavePiano() {
        setPreferredSize(new Dimension(900, 240));
        initMidi();
        buildKeys();

        chooseRandomTrapKey();
        chooseRandomCrashKey();
        chooseRandomTimedKey();
        chooseRandomOctaveKey();
        chooseRandomJumbleKey(); // Initialize Jumble Key

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Point p = e.getPoint();

                // Crash key
                if (isCrashKeyPressed(p)) {
                    triggerCrash(parentFrame);
                    return;
                }

                // Random octave key
                if (isRandomOctaveKeyPressed(p)) {
                    triggerRandomOctave();
                    return;
                }

                // Timed curse key
                if (isTimedKeyPressed(p)) {
                    triggerTimedCurse();
                    return;
                }

                // Trap key
                if (isTrapKeyPressed(p)) {
                    triggerPopups();
                    chooseRandomTrapKey();
                    chooseRandomCrashKey();
                    chooseRandomTimedKey();
                    chooseRandomOctaveKey();
                    chooseRandomJumbleKey();
                    repaint();
                    return;
                }

                // Jumble key
                if (isJumbleKeyPressed(p)) {
                    triggerJumbleKey();
                    return;
                }

                int note = getNoteAtPoint(p);

                if (note != -1) {
                    if (timedCurseActive) {
                        playNote(timedCurseNote);
                    } else if (jumbleActive) {
                        // Jumble: play a random note instead
                        int randomNote = getRandomNote();
                        playNote(randomNote);
                    } else {
                        playNote(note);
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                int note = getNoteAtPoint(e.getPoint());
                if (note != -1 && !jumbleActive) stopNote(note);
            }
        });
    }

    public void setParentFrame(JFrame frame) {
        this.parentFrame = frame;
    }

    private void initMidi() {
        try {
            synth = MidiSystem.getSynthesizer();
            synth.open();
            channel = synth.getChannels()[0];
            channel.programChange(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buildKeys() {
        int numWhite = NUM_OCTAVES * WHITE_PER_OCT;
        int numBlack = NUM_OCTAVES * BLACK_PER_OCT;

        whiteKeys = new Rectangle[numWhite];
        blackKeys = new Rectangle[numBlack];
        whiteKeyNotes = new int[numWhite];
        blackKeyNotes = new int[numBlack];

        int whiteW = 30, whiteH = 180;
        int blackW = 18, blackH = 110;

        int x = 10;
        int wi = 0, bi = 0;

        int[] whiteOffsets = {0, 2, 4, 5, 7, 9, 11};
        int[] blackOffsets = {1, 3, 6, 8, 10};

        for (int oct = 0; oct < NUM_OCTAVES; oct++) {

            for (int i = 0; i < whiteOffsets.length; i++) {
                whiteKeys[wi] = new Rectangle(x, 50, whiteW, whiteH);
                whiteKeyNotes[wi] = 60 + oct * 12 + whiteOffsets[i];
                wi++;
                x += whiteW;
            }

            int baseX = 10 + oct * WHITE_PER_OCT * whiteW;
            int[] blackXOffsets = {
                    whiteW - blackW / 2,
                    2 * whiteW - blackW / 2,
                    4 * whiteW - blackW / 2,
                    5 * whiteW - blackW / 2,
                    6 * whiteW - blackW / 2
            };

            for (int i = 0; i < blackOffsets.length; i++) {
                blackKeys[bi] = new Rectangle(
                        baseX + blackXOffsets[i],
                        50,
                        blackW,
                        blackH
                );
                blackKeyNotes[bi] = 60 + oct * 12 + blackOffsets[i];
                bi++;
            }
        }
    }

    private int getNoteAtPoint(Point p) {
        for (int i = 0; i < blackKeys.length; i++)
            if (blackKeys[i].contains(p))
                return blackKeyNotes[i] + octaveShift;

        for (int i = 0; i < whiteKeys.length; i++)
            if (whiteKeys[i].contains(p))
                return whiteKeyNotes[i] + octaveShift;

        return -1;
    }

    private int getRandomNote() {
        if (rand.nextBoolean()) {
            int idx = rand.nextInt(whiteKeyNotes.length);
            return whiteKeyNotes[idx] + octaveShift;
        } else {
            int idx = rand.nextInt(blackKeyNotes.length);
            return blackKeyNotes[idx] + octaveShift;
        }
    }

    private void playNote(int note) {
        if (channel != null && note >= 0 && note <= 127)
            channel.noteOn(note, 90);
    }

    private void stopNote(int note) {
        if (channel != null && note >= 0 && note <= 127)
            channel.noteOff(note);
    }

    // Trap key
    private void chooseRandomTrapKey() {
        trapIsWhite = rand.nextBoolean();
        trapKeyIndex = trapIsWhite ?
                rand.nextInt(whiteKeys.length) :
                rand.nextInt(blackKeys.length);
    }

    private boolean isTrapKeyPressed(Point p) {
        return trapIsWhite ?
                whiteKeys[trapKeyIndex].contains(p) :
                blackKeys[trapKeyIndex].contains(p);
    }

    private void triggerPopups() {
        for (int i = 0; i < 5; i++) {
            JOptionPane.showMessageDialog(this,
                    "You pressed the cursed popup key!",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    // Crash key
    private void chooseRandomCrashKey() {
        crashIsWhite = rand.nextBoolean();
        do {
            crashKeyIndex = crashIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while ((crashIsWhite == trapIsWhite && crashKeyIndex == trapKeyIndex));
    }

    private boolean isCrashKeyPressed(Point p) {
        return crashIsWhite ?
                whiteKeys[crashKeyIndex].contains(p) :
                blackKeys[crashKeyIndex].contains(p);
    }

    private void triggerCrash(JFrame frame) {
        JOptionPane.showMessageDialog(this,
                "CRASH KEY pressed!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        if (frame != null) frame.dispose();
    }

    // Timed key
    private void chooseRandomTimedKey() {
        timedIsWhite = rand.nextBoolean();
        do {
            timedKeyIndex = timedIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while (
                (timedIsWhite == trapIsWhite && timedKeyIndex == trapKeyIndex) ||
                (timedIsWhite == crashIsWhite && timedKeyIndex == crashKeyIndex)
        );
    }

    private boolean isTimedKeyPressed(Point p) {
        return timedIsWhite ?
                whiteKeys[timedKeyIndex].contains(p) :
                blackKeys[timedKeyIndex].contains(p);
    }

    private void triggerTimedCurse() {
        timedCurseActive = true;

        timedCurseNote = timedIsWhite ?
                whiteKeyNotes[timedKeyIndex] :
                blackKeyNotes[timedKeyIndex];

        Timer timer = new Timer(20000, e -> {
            timedCurseActive = false;
            chooseRandomTimedKey();
            repaint();
        });

        timer.setRepeats(false);
        timer.start();
    }

    // Random octave key
    private void chooseRandomOctaveKey() {
        randomOctaveIsWhite = rand.nextBoolean();

        do {
            randomOctaveKeyIndex = randomOctaveIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while (
                (randomOctaveIsWhite == trapIsWhite && randomOctaveKeyIndex == trapKeyIndex) ||
                (randomOctaveIsWhite == crashIsWhite && randomOctaveKeyIndex == crashKeyIndex) ||
                (randomOctaveIsWhite == timedIsWhite && randomOctaveKeyIndex == timedKeyIndex)
        );
    }

    private boolean isRandomOctaveKeyPressed(Point p) {
        return randomOctaveIsWhite ?
                whiteKeys[randomOctaveKeyIndex].contains(p) :
                blackKeys[randomOctaveKeyIndex].contains(p);
    }

    private void triggerRandomOctave() {
        int randomOctave = rand.nextInt(5) - 2; // -2 to +2
        octaveShift = randomOctave * 12;

        JOptionPane.showMessageDialog(this,
                "Random Octave: " + randomOctave);

        chooseRandomOctaveKey();
        repaint();
    }

    // Jumble key
    private void chooseRandomJumbleKey() {
        jumbleIsWhite = rand.nextBoolean();

        do {
            jumbleKeyIndex = jumbleIsWhite ?
                    rand.nextInt(whiteKeys.length) :
                    rand.nextInt(blackKeys.length);
        } while (
                (jumbleIsWhite == trapIsWhite && jumbleKeyIndex == trapKeyIndex) ||
                (jumbleIsWhite == crashIsWhite && jumbleKeyIndex == crashKeyIndex) ||
                (jumbleIsWhite == timedIsWhite && jumbleKeyIndex == timedKeyIndex) ||
                (jumbleIsWhite == randomOctaveIsWhite && jumbleKeyIndex == randomOctaveKeyIndex)
        );
    }

    private boolean isJumbleKeyPressed(Point p) {
        return jumbleIsWhite ?
                whiteKeys[jumbleKeyIndex].contains(p) :
                blackKeys[jumbleKeyIndex].contains(p);
    }

    private void triggerJumbleKey() {
        JOptionPane.showMessageDialog(this,
                "Jumble Key Activated!\nAll notes will play randomly for 20 seconds!");

        jumbleActive = true;

        Timer timer = new Timer(20000, e -> {
            jumbleActive = false;
            chooseRandomJumbleKey();
            repaint();
        });
        timer.setRepeats(false);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int i = 0; i < whiteKeys.length; i++) {
            if (trapIsWhite && i == trapKeyIndex)
                g.setColor(Color.YELLOW);
            else if (crashIsWhite && i == crashKeyIndex)
                g.setColor(Color.MAGENTA);
            else if (timedIsWhite && i == timedKeyIndex)
                g.setColor(Color.GREEN);
            else if (randomOctaveIsWhite && i == randomOctaveKeyIndex)
                g.setColor(Color.CYAN);
            else if (jumbleIsWhite && i == jumbleKeyIndex)
                g.setColor(Color.PINK);
            else
                g.setColor(Color.WHITE);

            Rectangle r = whiteKeys[i];
            g.fillRect(r.x, r.y, r.width, r.height);
            g.setColor(Color.BLACK);
            g.drawRect(r.x, r.y, r.width, r.height);
        }

        for (int i = 0; i < blackKeys.length; i++) {
            if (!trapIsWhite && i == trapKeyIndex)
                g.setColor(Color.RED);
            else if (!crashIsWhite && i == crashKeyIndex)
                g.setColor(Color.MAGENTA);
            else if (!timedIsWhite && i == timedKeyIndex)
                g.setColor(Color.GREEN);
            else if (!randomOctaveIsWhite && i == randomOctaveKeyIndex)
                g.setColor(Color.CYAN);
            else if (!jumbleIsWhite && i == jumbleKeyIndex)
                g.setColor(Color.PINK);
            else
                g.setColor(Color.BLACK);

            Rectangle r = blackKeys[i];
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    public void shiftOctave(int semitones) {
        int newShift = octaveShift + semitones;
        if (Math.abs(newShift) <= MAX_SHIFT) {
            octaveShift = newShift;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            Q3SolutionFourOctavePiano piano = new Q3SolutionFourOctavePiano();

            JButton down = new JButton("Octave -");
            JButton up = new JButton("Octave +");

            down.addActionListener(e -> piano.shiftOctave(-12));
            up.addActionListener(e -> piano.shiftOctave(+12));

            JPanel controls = new JPanel();
            controls.add(down);
            controls.add(up);

            JFrame frame = new JFrame("4-Octave Piano");
            piano.setParentFrame(frame);

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            frame.add(controls, BorderLayout.NORTH);
            frame.add(piano, BorderLayout.CENTER);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}