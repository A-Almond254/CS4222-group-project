

import javax.sound.midi.*;
import javax.swing.*;
import java.awt.*;

public class PianoFull {

    private static MidiChannel channel;

    private static int baseNote = 48; // C3
    private static int octaveShift = 0;
    private static final int MAX_SHIFT = 2;
    private static final int MIN_SHIFT = -2;

    public static void main(String[] args) throws Exception {

        Synthesizer synth = MidiSystem.getSynthesizer();
        synth.open();
        channel = synth.getChannels()[0];

        JFrame frame = new JFrame("Java Piano – 4 Octaves");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 350);
        frame.setLayout(null);

        int whiteKeyWidth = 45;
        int whiteKeyHeight = 200;

        int blackKeyWidth = 28;
        int blackKeyHeight = 120;

        // Pattern of white keys in an octave
        int[] whiteNotes = {0, 2, 4, 5, 7, 9, 11};

        // Black key positions relative to white keys
        boolean[] hasBlack = {true, true, false, true, true, true, false};

        int x = 20;

        // Draw 4 octaves of white keys
        JButton[][] whiteKeys = new JButton[4][7];
        JButton[][] blackKeys = new JButton[4][5];

        for (int octave = 0; octave < 4; octave++) {
            for (int i = 0; i < 7; i++) {

                int note = baseNote + whiteNotes[i] + (octave * 12);

                JButton key = new JButton();
                key.setBackground(Color.WHITE);
                key.setBounds(x, 60, whiteKeyWidth, whiteKeyHeight);
                key.setBorder(BorderFactory.createLineBorder(Color.BLACK));

                int finalNote = note;
                key.addActionListener(e -> play(finalNote));

                frame.add(key);
                whiteKeys[octave][i] = key;

                x += whiteKeyWidth;
            }
        }

        // Draw black keys (placed between specific white keys)
        x = 20;

        for (int octave = 0; octave < 4; octave++) {
            int blackIndex = 0;

            for (int i = 0; i < 7; i++) {

                if (hasBlack[i]) {
                    int note = baseNote + whiteNotes[i] + 1 + (octave * 12);

                    JButton key = new JButton();
                    key.setBackground(Color.BLACK);
                    key.setForeground(Color.WHITE);

                    int bx = x + whiteKeyWidth - (blackKeyWidth / 2);
                    key.setBounds(bx, 60, blackKeyWidth, blackKeyHeight);

                    int finalNote = note;
                    key.addActionListener(e -> play(finalNote));

                    frame.add(key);
                    blackKeys[octave][blackIndex] = key;
                    blackIndex++;
                }

                x += whiteKeyWidth;
            }
        }

        // Octave shift buttons
        JButton down = new JButton("Octave -");
        down.setBounds(20, 10, 100, 30);
        down.addActionListener(e -> shiftOctave(-1));

        JButton up = new JButton("Octave +");
        up.setBounds(140, 10, 100, 30);
        up.addActionListener(e -> shiftOctave(1));

        frame.add(down);
        frame.add(up);

        frame.setVisible(true);
    }

    private static void play(int note) {
        int shifted = note + (octaveShift * 12);
        channel.noteOn(shifted, 100);
        new Timer(300, e -> channel.noteOff(shifted)).start();
    }

    private static void shiftOctave(int amount) {
        int newShift = octaveShift + amount;
        if (newShift >= MIN_SHIFT && newShift <= MAX_SHIFT) {
            octaveShift = newShift;
            System.out.println("Octave shift: " + octaveShift);
        }
    }
}